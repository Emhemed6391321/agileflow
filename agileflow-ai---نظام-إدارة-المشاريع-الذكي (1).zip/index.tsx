// This project has been converted to PHP.
// The React entry point is disabled to prevent errors in the PHP-focused environment.
// Please refer to index.php for the application source code.
