import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedTask, Priority } from "../types";

// Safely access process.env to avoid ReferenceError in browser
const getApiKey = () => {
  try {
    if (typeof process !== 'undefined' && process.env) {
      return process.env.API_KEY || '';
    }
  } catch (e) {
    console.warn('Error accessing process.env', e);
  }
  return '';
};

const apiKey = getApiKey();
const ai = new GoogleGenAI({ apiKey });

// Helper to get enum values for prompt
const priorityValues = Object.values(Priority).join(', ');

export const generateTasksFromDescription = async (projectDescription: string): Promise<GeneratedTask[]> => {
  if (!apiKey) {
    console.error("API Key missing");
    return [];
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `أنت خبير في إدارة المشاريع ومنهجية الأجايل (Agile).
      قم بتحليل وصف المشروع التالي وقم بإنشاء قائمة بمهام (User Stories) تقنية قابلة للتنفيذ.
      
      وصف المشروع: "${projectDescription}"
      
      يجب أن تكون الأولويات من ضمن القيم التالية: ${priorityValues}.
      النقاط (Points) تعبر عن الجهد المقدر (مثلاً 1, 2, 3, 5, 8).
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "عنوان المهمة بشكل مختصر وواضح" },
              description: { type: Type.STRING, description: "وصف تفصيلي للمهمة أو قصة المستخدم" },
              priority: { type: Type.STRING, description: "أولوية المهمة" },
              points: { type: Type.NUMBER, description: "نقاط الجهد المقدرة (Fibonacci sequence preferred)" }
            },
            required: ["title", "description", "priority", "points"]
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as GeneratedTask[];
    }
    return [];
  } catch (error) {
    console.error("Error generating tasks:", error);
    throw error;
  }
};

export const analyzeProjectRisks = async (projectDescription: string, taskCount: number): Promise<string> => {
  if (!apiKey) return "الرجاء توفير مفتاح API لاستخدام هذه الميزة.";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `قم بتحليل مخاطر مشروع يحتوي على ${taskCount} مهام.
      وصف المشروع: ${projectDescription}.
      قدم تقريراً موجزاً باللغة العربية عن المخاطر المحتملة وكيفية تجنبها.`,
    });
    return response.text || "لم يتم استرجاع أي تحليل.";
  } catch (error) {
    console.error("Error analyzing risks:", error);
    return "حدث خطأ أثناء تحليل المخاطر.";
  }
};